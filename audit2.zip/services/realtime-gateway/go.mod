module github.com/bangucup/realtime-gateway

go 1.23

require (
	github.com/coder/websocket v1.8.13
	github.com/redis/go-redis/v9 v9.7.3
)

require (
	github.com/cespare/xxhash/v2 v2.2.0 // indirect
	github.com/dgryski/go-rendezvous v0.0.0-20200823014737-9f7001d12a5f // indirect
)
